﻿Simple Drum (シンプルドラム)
(C) 2026 INRESET

A Mega Drive program made by INRESET.
It is a simple drum kit in the middle of the screen, played with the
buttons on your pad.


* Compatible platforms
- MARK 16
- Some Mega Drive emulators
  (Not all emulators are guaranteed.)


* How to play on MARK 16
1. Create a MARK16 folder at the root of the microSD card.
   (This is not the older MDTANG folder.)
2. Copy this ROM (simple_drum.bin) into the MARK16/ROMS folder.
3. Insert the card into the console and choose the game from the list.
   You can also add it with the Mark16Manager PC app.


* Controls
The title menu is Free / Session / Option.
Choose with up/down, and confirm with A, C or START.
Press START during play to return to the title. MODE is not used.

Default mapping
  A    Bass drum (kick)
  B    Snare
  C    Floor tom
  X    High tom
  Y    Mid tom
  Z    Rim / clap
  Up   Crash cymbal
  Down Open hi-hat
  Left Closed hi-hat
  Right  Ride cymbal

In Option you can change the pad type (AUTO / 6-button / 3-button),
layered sound (off / on; off by default), and the sound assigned to
each input. There is a reset-to-default command and a "cymbals first"
preset (hats and ride moved onto buttons). The 3-button default is
kick / snare / floor plus crash / ride / open and closed hats.
Settings are kept in RAM only and reset when you power off.
The menus can be used with a 3-button pad (up/down to move, left/right
to change a value, A/C/START to confirm, B to go back).


* Session mode
Choose Session on the title screen, then pick one of three original
tracks. Adjust the tempo (BPM) with left/right and start. After a
4-beat hi-hat count-in, a lead guitar, bass and power chords play,
and you can drum along freely.

  1. Rock 8-beat        default 130 BPM (90-170)
  2. Hard shuffle       default 156 BPM (110-190)
  3. Slow blues         default  84 BPM (60-120)

A guitarist appears on the right, and a beat counter (1-4) plus a
simple groove meter are shown at the top left (no fail condition).


* Sound
All drum samples are original synthesized sounds. Up to four sounds
can play at once. Turning layered sound on adds FM and PSG noise to
some voices.


* Terms
Free to play. Please do not redistribute it for sale.


* Credits
(C) 2026 INRESET
Art, music and drum sounds are all original works by INRESET.
This software was built with SGDK (MIT License).
In-game Japanese text was rasterized from the DotGothic16 font
(SIL Open Font License 1.1). See NOTICE.txt for the license texts.
