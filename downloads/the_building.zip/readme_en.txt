﻿THE BUILDING (ザ・ビルディング)
(C) 2026 INRESET

A playable prototype made by INRESET for Mega Drive systems.
You play an office worker climbing from the 2nd floor to the rooftop
of a high-rise hit by disaster (earthquake and fire), then escaping
by helicopter.


* Compatible platforms
- MARK 16
- Some Mega Drive emulators
  (Not all emulators are guaranteed.)


* How to play on MARK 16
1. Create a MARK16 folder at the root of the microSD card.
   (This is not the older MDTANG folder.)
2. Copy this ROM (the_building.bin) into the MARK16/ROMS folder.
3. Insert the card into the console and choose the game from the list.
   You can also add it with the Mark16Manager PC app.


* Controls
D-pad left/right   Walk (you speed up, then slide a little when you let go)
A / B / C          Jump (hold longer to jump higher; while on a ladder, jump off)
D-pad up/down      Climb or descend ladders and ropes.
                   Hold up in mid-air to grab a ledge.
D-pad down         Brace yourself on a sloping floor so you do not slide
While hanging      Up or forward to pull up (down or a button to let go)
A/B/C on a rope    Let go (hold left or right to leap that way)
START              From the title, start the intro. Press again during the
                   intro to skip to gameplay on the 2nd floor.


* Flow
Title, then an intro (lobby, elevator, arrival on the 2nd floor, and a
large explosion on the 1st floor; skippable with START), then stages 1-7
(four floors each, floors 2-28), then the rooftop. Grab the helicopter's
rope ladder to be rescued. You have 3 lives. After a miss, you restart
that stage from the beginning. Score, a timer, saving and pause are not
implemented yet.


* Terms
Free to play. Please do not redistribute it for sale.


* Credits
(C) 2026 INRESET
Art, music and sound effects are all original works by INRESET.
This software was built with SGDK (MIT License).
See NOTICE.txt for the license text.
